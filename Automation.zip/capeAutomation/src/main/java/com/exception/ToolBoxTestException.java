package com.exception;

/**
 * @author kuppuraj
 * */
public class ToolBoxTestException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ToolBoxTestException(Throwable t) {
		super(t);
	}

	public ToolBoxTestException(String msg, Throwable t) {
		super(msg, t);
	}

	public ToolBoxTestException(String msg) {
		super(msg);
	}

}
