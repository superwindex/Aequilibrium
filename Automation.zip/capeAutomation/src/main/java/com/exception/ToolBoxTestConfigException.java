package com.exception;

/**
 * @author kuppuraj
 * */
public class ToolBoxTestConfigException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ToolBoxTestConfigException() {
		super();
	}

	public ToolBoxTestConfigException(String msg) {
		super(msg);
	}

	public ToolBoxTestConfigException(Throwable t) {
		super(t);
	}

	public ToolBoxTestConfigException(String msg, Throwable t) {
		super(msg, t);
	}

}
