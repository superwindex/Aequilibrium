package com.training.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.exception.ToolBoxTestException;


public class SeleniumUtil
{
  private static final Logger LOG = Logger.getLogger(SeleniumUtil.class);
  
  /** Utility class should not have a public or default constructor */
  private SeleniumUtil()
  {
    
  }
  
  public static boolean isAlertPresent(WebDriver driver)
  {
    try
    {
      driver.switchTo().alert();
      return true;
    }
    catch (NoAlertPresentException Ex)
    {
      return false;
    }
  }
  
  public static boolean isElementPresent(WebDriver driver, By elementBy)
  {
    driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
    // logger.debug("Is element present"+selector);
    boolean returnVal = true;
    try
    {
      driver.findElement(elementBy);
    }
    catch (Exception e)
    {
      returnVal = false;
    }
    finally
    {
      driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    }
    return returnVal;
  }
  
  public static boolean switchToFrame(WebDriver driver, String frame)
  {

    LOG.info("switching in iframe");
    try
    {
      String str[] = frame.split("\\|");
      WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalWaitTimeout());
      for (int i = 0; i < str.length; i++)
      {
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(str[i]));
      }
      return true;
    }
    catch (Exception e)
    {
      LOG.error(e.toString());
      return false;
    }
  }
  
  /**
   * returns the handle to window that was the parent when the method was called
   * @param driver web driver or null if
   * @return handle to parent window
   */
  public static String switchToWindow(WebDriver driver)
  {
    String parentHandle = driver.getWindowHandle();     
    Set<String> handle = driver.getWindowHandles();
    if (handle.contains(parentHandle))
    {
      handle.remove(parentHandle);
    }
    for (String winHandle : handle)
    {       
      driver.switchTo().window(winHandle);
    }
    driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
    return parentHandle;
  }
  
	
	/**
	 * This method would drag and drop the source element to the destination location
	 * autoDelayMilliseconds is the delay time after each move, press or release action when performing drag and drop
	 * 
	 * @param sourceLocation - Source Location
	 * @param destinationLocation - Destination Location
	 * @param autoDelayMilliseconds - auto delay time in milliseconds after each robot action (e.g. mouseMove or mousePrelease)
	 * 
	 * @throws exception 
	 */	
	public static void dragAndDrop(int autoDelayMilliseconds, Point sourceLocation, Point destinationLocation)
	{
		try {
				Robot robot = new Robot();

				robot.setAutoDelay(autoDelayMilliseconds);
				robot.setAutoWaitForIdle(true);
				
				//mouse point over the source location
				robot.mouseMove(sourceLocation.getX(), sourceLocation.getY());	
				robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
	
				//mouse moves to the destination
				robot.mouseMove(destinationLocation.getX(), destinationLocation.getY());	
				robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);	
			} 
			catch (AWTException e) 
			{
				throw new  ToolBoxTestException(e);
			}
	}
	

  
  /**
   * The method waits till the given element is clickable and clicks the element
   * @param element The element to wait for and click
   */
  public static void waitAndClickElement(WebDriver driver, By elementBy)
  {
    try
    {
      WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalWaitTimeout());     
      WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(elementBy));
      LOG.info("Waiting till element is clickable " + element.getText());
      wait.until(ExpectedConditions.elementToBeClickable(element));
      //WebElement element = wait.until(ExpectedConditions.elementToBeClickable(elementBy));
      element.click();     
      
    }
    catch (Exception e)
    {
      LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
      throw new ToolBoxTestException(e);
    }

  }
  public static String waitAndGetElementText(WebDriver driver, By elementBy){
	  
	  WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalWaitTimeout());     
      WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(elementBy));
      return element.getText();
  }


  
  
  /**
   * The method waits till the given table row is selected.
   * The selection is checked through its class attribute with value "highlight"
   * If row selection does not use class attribute with value "highlight", this method won't work.
   * 
   * @param element The table row element to wait and to select
   *  
   */
  public static void waitAndSelectTableRow(WebDriver driver, final By elementBy)
  {
    try
    {
      LOG.info("Waiting till element is selected " + driver.findElement(elementBy).getText());
      WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalWaitTimeout());
      wait.until(
          new ExpectedCondition <Boolean>()
          {
            public Boolean apply(WebDriver driver)
            {
              try
              {
                 WebElement rowElement = driver.findElement(elementBy);
                 
                 //if class attribute has value "highlight", the row is selected
                 boolean isRowSelected = rowElement.getAttribute("class").contains("highlight");

                // if a table row is not selected
                // Click the table row
                if (!isRowSelected )
                {
                  SeleniumUtil.waitAndClickElement(driver, elementBy);
                  return false;
                }
                else
                {
                  return true;
                }
                  
              }
              catch (Exception e)
              {
                LOG.error("Exception occured:" + e.toString(), e);
                throw new ToolBoxTestException("Exception occured:" + e);
              }
              
            }
          }
      
      );
    }
    catch (Exception e)
    {
      LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
      throw new ToolBoxTestException(e);
    }

  }  
  /**
   * enter the data provided into the text field given.
   * 
   * @param driver web driver
   * @param elementBy text field's by locator
   * @param data value to enter into text field
   */
  public static void writeTextByLocator(WebDriver driver, By elementBy, String data)
  {
    WebElement element = driver.findElement(elementBy);
    element.click();
    element.clear();
    element.click();
    element.sendKeys(data);
  }
  
  /**
   * First clear given rich text field elementBy and then enter the data provided
   * 
   * Precondition: The rich text field has already been enabled by clicking RTEviewer element.
   * 
   * @param driver web driver
   * @param elementBy rich text field's by locator
   * @param data value to enter into rich text field
   */
  public static void writeTextInRTEditorByLocator(WebDriver driver, By elementBy, String data)
  {
    WebElement element = driver.findElement(elementBy);
    clearRichTextfield(driver, elementBy);
    element.sendKeys(data);
  }
  
	/**
	 * 
	 * Clear RTE field specified by elementBy
	 * 
	 * Precondition: The rich text field has already been enabled by clicking RTEviewer element.
	 * 
	 * @param elementBy EDITOR By element e.g. LESSON_OBJECTIVE_EDITOR = By.id("objectives_editor");
	 */
	public static void clearRichTextfield(WebDriver driver, By elementBy)
	{
		String Ctrl_A_Delete = Keys.chord(Keys.CONTROL, "a", Keys.DELETE);
		driver.findElement(elementBy).sendKeys(Ctrl_A_Delete);
	}
  
  /*
	 * This method fires up an alert, wait for the alert to be presented and then click OK button in alert box.
	 *
	 */
	// [Wen]: Added print alert message 
  public static  void waitAndAcceptAlert(WebDriver driver)
  {
	try
	{
		WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalWaitTimeout());
		wait.until(ExpectedConditions.alertIsPresent());
			 
		//Switch focus to the alert popup
		Alert alert = driver.switchTo().alert();

		//Print alert message
		System.out.println("Popup message: " + alert.getText());
		
		//Click OK button in alert popup
		alert.accept();
	}
	catch (Exception e)
	{
		LOG.error("EXCEPTION_CAUGHT::" + e.getMessage(), e);
		throw new ToolBoxTestException(e);
	}
  }
	
  // The method waits till element is clickable
  public static void clickByFindElement(WebDriver driver, String locateBy, String data)
  {

	LOG.info("Waiting till element is clickable" + data);
	try
	{
		if (locateBy.equalsIgnoreCase("id"))
		{
			driver.findElement(By.id(data)).click();
		}
		else if (locateBy.equalsIgnoreCase("xpath"))
		{
			driver.findElement(By.xpath(data)).click();
		}
		driver.manage().timeouts().implicitlyWait(ConfigUtil.getGlobalImplicitWait(), TimeUnit.SECONDS);
	}
	catch (Exception e)
	{
		LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
		throw new ToolBoxTestException(e);
	}

  }
		
  public static void handleMultipleWindows(WebDriver driver, String parentWindow, Set<String> windows) 
  {
	try 
	{								
		// Now we will iterate using Iterator
		Iterator<String> windowsIterator = windows.iterator();
		while (windowsIterator.hasNext()) 
		{
			String child_window = windowsIterator.next();
			driver.switchTo().window(parentWindow);

			// Here we will compare if parent window is not equal to
			// child window then we will close the popup

			if (!parentWindow.equals(child_window)) 
			{
				try 
				{
					LOG.info("Handling popup window");
					String data = System.getProperty("user.dir") + "\\Test_files\\Save_Dialog_IE_64.exe";
					Thread.sleep(2000L);
					Runtime.getRuntime().exec(data);									
					Thread.sleep(2000L);
					WebDriverWait wait = new WebDriverWait(driver, ConfigUtil.getGlobalImplicitWait());
					wait.until(ExpectedConditions.numberOfwindowsToBe(1));
				} 
				catch (Exception e)
				{
					LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
					driver.switchTo().window(child_window);
					driver.close();
				}

			}

		}
		// once all pop up closed now switch to parent window
		driver.switchTo().window(parentWindow);
					
	} 
	catch (Exception e) 
	{
		LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
		throw new ToolBoxTestException(e);
	}

  }
		
  public static void windowHandle(WebDriver driver, String parentWindow) throws Exception
  {
	driver.manage().timeouts().implicitlyWait(ConfigUtil.getGlobalImplicitWait(), TimeUnit.SECONDS);
	Thread.sleep(3000);
	Set<String> windows = driver.getWindowHandles();
	if(windows.size() == 1)
	{
		driver.switchTo().window(parentWindow);
	}
	else
	{
		handleMultipleWindows(driver, parentWindow, windows);
	}
  }

}
