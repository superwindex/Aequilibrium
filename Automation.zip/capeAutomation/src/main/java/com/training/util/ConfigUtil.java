package com.training.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.exception.ToolBoxTestConfigException;

public class ConfigUtil
{
  private static final Logger LOG = Logger.getLogger(ConfigUtil.class);

  private static final String CONFIG_FILE_NAME = "config";

  // property keys 
  private static final String BROWSER = "browser";
  private static final String GLOBAL_DOUBLE_WAIT_SLEEP = "global.double.wait.sleep.miliseconds";
  private static final String GLOBAL_IMPLICIT_WAIT = "global.implicit.wait.seconds";
  private static final String GLOBAL_WAIT_TIMEOUT = "global.webDriver.wait.seconds";
  private static final String GLOBAL_TRIPLE_WAIT_TIMEOUT = "global.webDriver.triple.wait.seconds";
  private static final String GLOBAL_WAIT_TIMEOUT_MINUTES = "global.webDriver.wait.minutes";
  
  private static final String BASE_URL = "base.url";
  private static final String TOOLBOX_LOGIN_USER = "login.user";
  
  private static ResourceBundle CONFIG_RESOURCE = loadConfigFromPropertiesFile();
  private static final String TOOLBOX_PARTIAL_URL = "toolbox.partial.url";
  /** Utility class should not have a public or default constructor */
  private ConfigUtil()
  {
    
  }
  
  /**
   * Load the training config property file
   * @return The training_config.properties file
   */
  protected static ResourceBundle loadConfigFromPropertiesFile()
  {
    ResourceBundle config = null;
    try
    {
      config = ResourceBundle.getBundle(CONFIG_FILE_NAME);
    } 
    catch (MissingResourceException mre)
    {
      LOG.error(mre.toString());
      throw new ToolBoxTestConfigException("Cannot find '" + CONFIG_FILE_NAME + ".properties' file in classpath", mre);
      
    }
    return config;
  }

  /**
   * copy to the archive folder
   */
  public static void copyToArchiveFolder()
  {
    String destFileName = "test-output";
    String reportPath = System.getProperty("user.dir") + "\\test-output";   
    String archievePath = System.getProperty("user.dir") + "\\Archieve_Output\\";

    File source = new File(reportPath);
    SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH-mm-ss");
    String ts = sdf.format(source.lastModified());
    File destination = new File(archievePath+destFileName+"_"+ts);
    try
    {
      FileUtils.copyDirectory(source,destination);
      System.out.println("Done");
    }
    catch (IOException e)
    {
      LOG.error("Exception occured on moving the report folder to archieve folder:::" +e.toString());
    }
  }

  /**
   * @return the browser from the property file.
   */
  public static String getBrowser()
  {
    return CONFIG_RESOURCE.getString(BROWSER);
  }
  
  /** 
   * @return the global implicit wait from the property file.  If can't find a value then use 10 as the default.
   */
  public static int getGlobalDoubleWaitSleep()
  {
    int waitTime = 0;
    try
    {
      waitTime = Integer.valueOf(((String) CONFIG_RESOURCE.getString(GLOBAL_DOUBLE_WAIT_SLEEP))).intValue();
    }
    catch (NumberFormatException nfe)
    {
      LOG.warn("Could not convert value of key '" + GLOBAL_DOUBLE_WAIT_SLEEP + "' to a number.  Using default of 500 miliseconds.");
      waitTime = 500;
    }
    
    return waitTime;
  }
  
  /** 
   * @return the global implicit wait from the property file.  If can't find a value then use 10 as the default.
   */
  public static int getGlobalImplicitWait()
  {
    int waitTime = 0;
    try
    {
      waitTime = Integer.valueOf(((String) CONFIG_RESOURCE.getString(GLOBAL_IMPLICIT_WAIT))).intValue();
    }
    catch (NumberFormatException nfe)
    {
      LOG.warn("Could not convert value of key '" + GLOBAL_IMPLICIT_WAIT + "' to a number.  Using default of 60.");
      waitTime = 10;
    }
    
    return waitTime;
  }

  /** 
   * @return the global wait timeout from the property file.  If can't find a value then use 60 as the default.
   */
  public static int getGlobalWaitTimeout()
  {
    int waitTime = 0;
    try
    {
      waitTime = Integer.valueOf(((String) CONFIG_RESOURCE.getString(GLOBAL_WAIT_TIMEOUT))).intValue();
    }
    catch (NumberFormatException nfe)
    {
      LOG.warn("Could not convert value of key '" + GLOBAL_WAIT_TIMEOUT + "' to a number.  Using default of 60.");
      waitTime = 60;
    }
    
    return waitTime;
  }

  /** 
   * @return the global wait timeout from the property file.  If can't find a value then use 180 as the default.
   */
  public static int getGlobalTrippleWaitTimeout()
  {
    int waitTime = 0;
    try
    {
      waitTime = Integer.valueOf(((String) CONFIG_RESOURCE.getString(GLOBAL_TRIPLE_WAIT_TIMEOUT))).intValue();
    }
    catch (NumberFormatException nfe)
    {
      LOG.warn("Could not convert value of key '" + GLOBAL_TRIPLE_WAIT_TIMEOUT + "' to a number.  Using default of 180.");
      waitTime = 180;
    }
    
    return waitTime;
  }
  

  /** 
   * @return the global wait timeout in minutes from the property file.  If can't find a value then use 540s (9 minutes) as the default.
   */
  public static int getGlobalWaitMinutesTimeout()
  {
    int waitTime = 0;
    try
    {
      waitTime = Integer.valueOf(((String) CONFIG_RESOURCE.getString(GLOBAL_WAIT_TIMEOUT_MINUTES))).intValue();
    }
    catch (NumberFormatException nfe)
    {
      LOG.warn("Could not convert value of key '" + GLOBAL_TRIPLE_WAIT_TIMEOUT + "' to a number.  Using default of 9 minutes (540 seconds).");
      waitTime = 540;
    }
    
    return waitTime;
  }
  
  /**
   * @return the toolbox URL from the property file.
   */
  public static String getToolboxUrl()
  {
    return CONFIG_RESOURCE.getString(BASE_URL);
  }
  
  /**
   * @return the toolbox Login User name from the property file.
   */
  public static String getToolboxUser()
  {
    return CONFIG_RESOURCE.getString(TOOLBOX_LOGIN_USER);
  }
  
  public static String getToolboxPartialUrl()
  {
    return CONFIG_RESOURCE.getString(TOOLBOX_PARTIAL_URL);
  }
}
