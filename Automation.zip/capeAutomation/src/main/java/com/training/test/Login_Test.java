package com.training.test;


import com.exception.ToolBoxTestConfigException;
import com.training.util.SeleniumUtil;
import com.Helper.DateHelper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.io.File;
import java.security.PrivateKey;
import java.sql.Driver;

import org.testng.Assert;
import static org.testng.Assert.assertEquals;
import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;


public class Login_Test extends BaseTest{

	private static final Log LOG = LogFactory.getLog(Login_Test.class.getName());
	
		
    @Test (priority=1)
    public void OpenPage(){

        try {
            System.out.println("Open Page");
            System.out.println("Title: " + getDriver().getTitle());
                        
            new WebDriverWait(getDriver(),5).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.login_logo")));
            assertEquals("Swag Labs", getDriver().getTitle());
            System.out.println("Test scenario passed, Swag Labs page opens up correctly");
                                         
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
	
    @Test (priority=2)
    public void TestCase1(){

        try {
            System.out.println("Starting Test Case 1...");
            
            //Enter Password
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));           
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys("secret_sauce"); 
        	//Clear Username
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));
        	getDriver().findElement(By.cssSelector("input#user-name")).clear();
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	
        	assertEquals(true, getDriver().findElement(By.cssSelector("h3[data-test='error']")).isDisplayed());
        	
        	if (getDriver().findElement(By.cssSelector("h3[data-test='error']")).getText().contains("Username is required"))
        	{
        		System.out.println("Error message is correct");
        	}
        	
        	else
        	{
        		System.out.println("Error message is not correct");		
        	}       	        		
                                         
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
     
    
    @Test (priority=3)
    public void TestCase2(){

        try {
            System.out.println("Starting Test Case 2...");
            
            //Enter Username
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));           
        	getDriver().findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
        	//Clear Password
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys(Keys.CONTROL + "a", Keys.DELETE);
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	
        	assertEquals(true, getDriver().findElement(By.cssSelector("h3[data-test='error']")).isDisplayed());
        	
        	if (getDriver().findElement(By.cssSelector("h3[data-test='error']")).getText().contains("Password is required"))
        	{
        		System.out.println("Error message is correct");
        	}
        	
        	else
        	{
        		System.out.println("Error message is not correct");		
        	}       	        		
                                         
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
    
    
    @Test (priority=4)
    public void TestCase3(){

        try {
            System.out.println("Starting Test Case 3...");
            
            //Enter Username
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));
        	getDriver().findElement(By.cssSelector("input#user-name")).clear();
        	getDriver().findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
        	//Enter Password
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys(Keys.CONTROL + "a", Keys.DELETE);
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys("password");
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	
        	assertEquals(true, getDriver().findElement(By.cssSelector("h3[data-test='error']")).isDisplayed());
        	
        	if (getDriver().findElement(By.cssSelector("h3[data-test='error']")).getText().contains("Username and password do not match any user in this service"))
        	{
        		System.out.println("Error message is correct");
        	}
        	
        	else
        	{
        		System.out.println("Error message is not correct");		
        	}       	        		
                                         
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
    
    
    @Test (priority=5)
    public void TestCase4(){

        try {
            System.out.println("Starting Test Case 4...");
            
            //Enter Username
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));
        	getDriver().findElement(By.cssSelector("input#user-name")).clear();
        	getDriver().findElement(By.cssSelector("input#user-name")).sendKeys("username");
        	//Enter Password
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys(Keys.CONTROL + "a", Keys.DELETE);
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys("secret_sauce");
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	
        	assertEquals(true, getDriver().findElement(By.cssSelector("h3[data-test='error']")).isDisplayed());
        	
        	if (getDriver().findElement(By.cssSelector("h3[data-test='error']")).getText().contains("Username and password do not match any user in this service"))
        	{
        		System.out.println("Error message is correct");
        	}
        	
        	else
        	{
        		System.out.println("Error message is not correct");		
        	}       	        		
                                         
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
    
    
    @Test (priority=6)
    public void TestCase5(){
   	
        try {
            System.out.println("Starting Test Case 5...");
                       
            //Enter Username
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));
        	getDriver().findElement(By.cssSelector("input#user-name")).clear();
        	getDriver().findElement(By.cssSelector("input#user-name")).sendKeys("locked_out_user");
        	//Enter Password
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys(Keys.CONTROL + "a", Keys.DELETE);
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys("secret_sauce");
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	       	
        	assertEquals(true, getDriver().findElement(By.cssSelector("h3[data-test='error']")).isDisplayed());
        	
        	if (getDriver().findElement(By.cssSelector("h3[data-test='error']")).getText().contains("Sorry, this user has been locked out"))
        	{
        		System.out.println("Error message is correct");
        	}
        	
        	else
        	{
        		System.out.println("Error message is not correct");		
        	}  
                        	     	        		                                      
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
    
    
    @Test (priority=7)
    public void TestCase6(){

    	String nextURL= "";
    	
        try {
            System.out.println("Starting Test Case 6...");
                       
            //Enter Username
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#user-name"));
        	getDriver().findElement(By.cssSelector("input#user-name")).clear();
        	getDriver().findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
        	//Enter Password
        	SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input#password"));
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys(Keys.CONTROL + "a", Keys.DELETE);
        	getDriver().findElement(By.cssSelector("input#password")).sendKeys("secret_sauce");
        	//Click LOGIN button
            SeleniumUtil.waitAndClickElement(getDriver(), By.cssSelector("input[value='LOGIN']"));
        	       	
            new WebDriverWait(getDriver(),5).until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.product_label")));
            assertEquals("Products", getDriver().findElement(By.cssSelector("div.product_label")).getText());
            nextURL = getDriver().getCurrentUrl();
            System.out.println("Products page is loaded. URL: " + nextURL);
                        	     	        		                                      
        }

        catch (AssertionError e){
            System.out.println(e);
			LOG.error(e.toString());
            throw new Error(e);
        }

    }
    

}
