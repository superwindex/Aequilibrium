package com.training.test;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.Helper.DateHelper;
import com.Helper.DriverHelper;
import com.Helper.SeleniumConstants;
import com.Helper.XlsHelper;
import com.exception.ToolBoxTestConfigException;
import com.exception.ToolBoxTestException;
import com.training.util.ConfigUtil;
import com.training.util.SeleniumUtil;

/**
 * Base test class.  All test classes should extend from this base class.  It has the before and after methods.  It also
 * has the data provider method
 *
 */
public class BaseTest
{
  private static final Logger LOG = Logger.getLogger(BaseTest.class);
  
  /**
   * Retrieve data from spreadsheet
   * 
   * @param method - method name to get data
   * @return - array of the data
   * @throws Exception - thrown if an exception occurs
   */
  
  
  @DataProvider(name = "test1")
  public Object[][] getData(Method method) throws Exception
  {
    try
    {
      LOG.info("Inside data provider getData()");

      int testCaseRow;
      String testCaseName = method.getName();

      // Fetching the Test Case row number from the Test Data Sheet
      testCaseRow = getXlsHelper().getRowContains(testCaseName, 0);

      // Get the Data for the test case
      Object[][] testObjArray = getXlsHelper().getCellData(testCaseRow);
      return (testObjArray);
    }
    catch (Exception e)
    {
      LOG.error("Exception in reading testData from excel::" + e.getMessage());
      throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);
    }
  } 
  
    
  /**
   * method run before test suit executed.  Will start the web driver, launch toolbox, login and select the training
   * tab
   * 
   * @throws Exception - thrown if an exception occurs
   */
  @BeforeSuite
  public void beforeSuite() throws Exception
  {

    // Setting up the log file
    String xmlPath = "log4j.xml";
    SetUpLog(xmlPath);

    LOG.info("Entering Suite... ");
    LOG.info("Start running testing time: " + DateHelper.getStartTime());

    // Copy the old report folder to archive folder
    ConfigUtil.copyToArchiveFolder();
    
    // Starting the driver
    if (getDriver() == null)
    {
      DriverHelper.getInstance().startDriver(ConfigUtil.getBrowser());
    }

    // Navigating to the url
    LOG.info("Navigate to URL");
    getDriver().get("https://www.saucedemo.com/index.html");
  }

  /**
   * method called before class methods are executed.
   * 
   * @throws Exception - thrown if an exception occurs
   */
  @BeforeClass
  public void beforeClass() throws Exception
  {
    try
    {     
      LOG.info("Entering class: " + this.getClass().getName());
      
    }
    catch (Exception e)
    {
      throw new ToolBoxTestException("Exception occured:" + e);
    }

  }

  /**
   * method called before test method
   * 
   * @param method - method about to be executed
   * @throws Exception - thrown if an exception occurs
   */
  @BeforeMethod
  public void beforeMethod(Method method) throws Exception
  {
    LOG.info("Entering method: " + method.getName());
  }

  /**
   * method called after test method completed.  Logs the result of the test.
   * 
   * @param result - result of text execution
   * @throws Exception - thrown if an exception occurs
   */
  @AfterMethod
  public void afterMethod(ITestResult result) throws Exception
  {
    LOG.info("Preparing to exit method: " + result.getMethod().getMethodName());
    LOG.info("Test result: " + DriverHelper.getStatusString(result.getStatus()));
    LOG.info("Exiting method: " + result.getMethod().getMethodName());
    
    if (ITestResult.FAILURE == result.getStatus())
    {
    	TakesScreenshot ts = (TakesScreenshot)getDriver();
    	File source = ts.getScreenshotAs(OutputType.FILE);
    	FileUtils.copyFile(source, new File("./Screenshot/"+result.getName()+".png"));
    	System.out.println("Screenshot taken");
    } 
    
  }

  /**
   * method called after all test methods in a class are completed.  Return to the training main page.
   */
  @AfterClass
  public void afterClass()
  {
    try
    {
      LOG.info("Exiting class: " + this.getClass().getName());
      //getDriver().switchTo().defaultContent();
      // Switching to Process bar frame
      //SeleniumUtil.switchToFrame(getDriver(), SeleniumConstants.PROCESSBAR_FRAMEID);
      
      //Clicking on Select a Training Function tab
      //By trainingTab = By.xpath(SeleniumConstants.STF_PB_XPATH);
      //SeleniumUtil.waitAndClickElement(getDriver(), trainingTab);
      
      //getDriver().manage().timeouts().implicitlyWait(ConfigUtil.getGlobalImplicitWait(), TimeUnit.SECONDS);
      
      // Switching to Main Frame
      //getDriver().switchTo().defaultContent();
      //SeleniumUtil.switchToFrame(getDriver(), SeleniumConstants.MAINFRAMEID);
      //LOG.info("Check for Training main page");
    }
    catch (Exception e)
    {
      throw new ToolBoxTestException("Exception occured:" + e);
    }
    
  }

  /**
   * method called after the test suit is complete.  Quits the web driver.
   */
  @AfterSuite(alwaysRun = true)
  public void afterSuite()
  {
    if (getDriver() != null)
    {
      LOG.info("Inside afterSuite... ");
      DriverHelper.getInstance().cleanDriverSession();

      getDriver().quit();
    }
    LOG.info("Exiting Suite... ");
  }

  /**
   * setup the log4j 
   * @param xmlPath
   */
  private void SetUpLog(String xmlPath)
  {
    URL url = getClass().getClassLoader().getResource(xmlPath);
    DOMConfigurator.configure(url);
  }

  /**
   * @return returns the web driver.
   */
  protected WebDriver getDriver()
  {
    return DriverHelper.getInstance().getDriver();
  }

  /**
   * @return returns XslHelper instance used for reading spreadsheet data
   */
  protected XlsHelper getXlsHelper()
  {
    return XlsHelper.getInstance();
  }
}
