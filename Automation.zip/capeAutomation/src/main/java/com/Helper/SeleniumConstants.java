package com.Helper;

/**
 * @author Hemachand 
 */
public class SeleniumConstants
{

	public static String MAINFRAMEID = "documentContainer|documentContent|trainingtab|mainFrm";
	public static String ADMINFUNCFRAMEID = "documentContainer|documentContent|btipps|adminFunctions";
	public static String BTIPPS_FRAMEID = "documentContent|btipps";
	public static String PROCESSBAR_FRAMEID = "documentContainer|documentContent|trainingtab|processBarFrm";
  	public static String SUBJECT_FRAMEID = "documentContainer|documentContent|AddSubjectWin";
  	public static String IMPORT_FRAMEID = "bodyContainer|importForm";

	public static String ALERT_ACCEPT_BTN_XPATH = "//input[@value='Accept']";
	public static String MAIN_XPATH = "//a[contains(.,'Main')]";
	public static String TRAINING_XPATH = "//a[contains(.,'Training')]";

	public static String INSTRUCTORTOOL_BTN_XPATH = "//span[@title='Instructor Tools']/span/span";
	public static String APPLY_BTN_XPATH = "//div[@class='functionButtons']/img";
	public static String SELECTFUNCT_XPATH = "(//span[contains(.,'Select a Function')])[2]";
	public static String USERID_TEXT_XPATH = "//input[@name='1']";
	public static String INSTRUCTOR_TOOLBTN_XPATH = "//span[@title='Instructor Tools']/span/span";
	public static String CONFIG_CELLS_XPATH = "//table[@id='configTable']/tbody/tr/td";
	public static String CONFIG_FIRST_CONFIG_XPATH = "//table[@id='configTable']/tbody/tr/td[2]";
	
	public static String AIRPLANE_TABLE_ALL_CELL_XPATH = "//table[@id='airplaneTable']/tbody/tr/td";
	
	public static String FIRSTSLIDEPAIR_NOCONTENT_XPATH ="//tbody[@id='slideSorterTBody']/tr[1]/td[1]/div[2]/div[1]/div[2]/div[1]/img";
	public static String SECONDSLIDEPAIR_IMG_XPATH ="//tbody[@id='slideSorterTBody']/tr[2]/td[1]/div[2]/div[1]/div[2]/img";
	public static String SECONDSLIDEPAIR_NOCONTENT_XPATH ="//tbody[@id='slideSorterTBody']/tr[2]/td[1]/div[2]/div[1]/div[2]/div[1]/img";
	public static String STF_PB_XPATH = "//span[contains(.,'Select a Training Function')]";
	public static String TRAIN_HEAD_XPATH = "//span[@class='chromeTitle'][contains(.,'Select a Training Function')]";

	//Course Catalog xpath
	public static String CATALOG_PAGEHEAD = "//h1[@class='pageHead'][contains (text(), 'Course Catalog')]";
	public static String COURSE_MASTER_TABLE_XPATH = "//table[@id='templateTable']/tbody/tr[@coursenumber='";
	public static String COURSE_TABLE_ALL_CELL_XPATH = "//table[@id='instanceTable']/tbody/tr/td";
	public static String COURSE_TABLE_ALL_ROW_XPATH = "//table[@id='instanceTable']/tbody/tr";

	
	public static String GO_BTN_ID = "goButton";
	public static String GETLESSONS_ID = "pb_lessonCat";	
	public static String SLIDESORTER_ID = "slideSorterTBody_1";	
	
}
