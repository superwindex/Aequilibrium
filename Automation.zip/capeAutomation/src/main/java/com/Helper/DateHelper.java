package com.Helper;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;


import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * @author 
 * */
public class DateHelper {

	private static DateHelper instance = new DateHelper();
	private static String startTime;
	private static long startMilliTime;
 
	private DateHelper() {
	}

	public static DateHelper getInstance() {
		return instance;
	}

		
	public static void setStartMilliTime() {
		//milliTime = new Date().getTime();
		startMilliTime = System.currentTimeMillis();
	}
	
	public static  long getStartMilliTime() { 
		return startMilliTime;
	}
	
	
	public static  void setEndMilliTime() {
		//milliTime = new Date().getTime();
		startMilliTime = System.currentTimeMillis();
	}
	
	public static long getEndMilliTime() { 
		return startMilliTime;
	}

	
	
	public static String genCurrentDateAsString() {
		Calendar calendar = new GregorianCalendar();
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);

		String d = Integer.toString(dayOfWeek);
		String h = Integer.toBinaryString(hour);
		String m = Integer.toString(minute);

		String dateHourMinute = d + h + m;

		return dateHourMinute;
	}

	public static  String getCurrentDateTime() {
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}
	
	//Function written by Wen
	public static  String getCurrentDate() {
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		
		Date date = new Date();
		
		return dateFormat.format(date);
	}
    	
	public static String getCurrentDateTimeAsYear() {
		
		DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmssZ");
		
		Calendar cal = Calendar.getInstance();
		return dateFormat.format(cal.getTime());
	}

	
	
	public static  String getDurationMsg(String msg, long documentProcessingStartTime, long documentProcessingEndTime) {
		return msg + " " + getLogDurationMsg(documentProcessingStartTime, documentProcessingEndTime);
	}

	public static String getLogDurationMsg(long startTime, long endTime) {
		long totalInMillis = endTime - startTime;
		
		long days = TimeUnit.MILLISECONDS.toDays(totalInMillis);
		long hours = TimeUnit.MILLISECONDS.toHours(totalInMillis);
		long minutes = TimeUnit.MILLISECONDS.toMinutes(totalInMillis);
		long seconds = TimeUnit.MILLISECONDS.toSeconds(totalInMillis);
		
//		String totalTimeTaken = String.format("%d min, %d sec, %d millis",
//						minutes,
//						seconds - TimeUnit.MINUTES.toSeconds(minutes),
//						totalInMillis - TimeUnit.SECONDS.toMillis(seconds)		
//				);
//		
		
		String totalTimeTaken = String.format("%d days, %d hours, %d min, %d sec",
				days,
				hours,
				minutes,
				seconds - TimeUnit.MINUTES.toSeconds(minutes)
						
		);
		
		return totalTimeTaken;
	}

	public static String getStartTime() {
		return startTime;
	}

	public static void setStartTime() {  
		startTime = getCurrentDateTime();
		startMilliTime = System.currentTimeMillis(); 
	}
}
