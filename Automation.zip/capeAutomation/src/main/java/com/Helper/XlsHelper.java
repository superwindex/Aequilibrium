package com.Helper;

import java.io.*;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.exception.ToolBoxTestConfigException;

public class XlsHelper
{
	private static Log LOG = LogFactory.getLog(XlsHelper.class.getName());
	public static String filePath = System.getProperty("user.dir") + "\\src\\main\\resources\\eform_fields_and_rules.xlsx";
	public FileInputStream fis = null;
	private XSSFWorkbook workbook = null;
	private XSSFSheet sheet = null;
	private XSSFRow row = null;
	private XSSFCell cell = null;

	private static XlsHelper instance = new XlsHelper();
	
	public XlsHelper()
	{
		try
		{
			fis = new FileInputStream(filePath);
			workbook = new XSSFWorkbook(fis);
			//use sheet index number
			//sheet = workbook.getSheetAt(0);
			//use sheet name
			sheet = workbook.getSheet("ProjectCode");
			fis.close();
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			LOG.error("Exception in reading testData from excel::" + e.getMessage());
			throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);
		}

	}
	
	public static XlsHelper getInstance() {
	    return instance;
	  }

	public Object[][] getCellData(int rowNum) throws Exception
	{
		String[][] cellArray = null;
		int i = 0;
		int j = 0;
		int columnCount =0;
		try
		{
	    int rowCount = getDataRowCount(rowNum);
			int cellCount = row.getLastCellNum();
			for (int c = 1; c < cellCount; c++) {
		        Cell cell = row.getCell(c);
		        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
		        	columnCount++;
		    }
			cellArray = new String[rowCount][columnCount];

			for (i = 0; i < rowCount; i++)
			{
			  row = sheet.getRow(rowNum + i);
			  Iterator<Cell> cells = row.cellIterator();
	      
  			  j = 0;
				while (cells.hasNext()) {
					cell = (XSSFCell) cells.next();
					String cellData = cell.getStringCellValue();
					if (cell.getColumnIndex() != 0
							&& cell.getCellType() != Cell.CELL_TYPE_BLANK) {
						cellArray[i][j] = cellData;
						j++;

					}

				}
			}
		}
		catch (Exception e)
		{

			LOG.error("Exception in reading testData from excel::" + e.getMessage(), e);
			throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);

		}
		return (cellArray);

	}

	public String getCellData(int RowNum, int ColNum) throws Exception
	{
		String cellData = "";
		try
		{
			row = sheet.getRow(RowNum);
			if(row != null)
			{
				cell = row.getCell(ColNum);
				if (cell != null)
				{
					cellData = cell.getStringCellValue();
				}
			} 
			return cellData;
		}
		catch (Exception e)
		{

			LOG.error("Exception in reading testData from excel::" + e.getMessage(), e);
			throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);

		}

	}

	public int getRowContains(String sTestCaseName, int colNum) throws Exception
	{

		int i;

		try
		{

			int rowCount = getRowUsed();

			for (i = 0; i <= rowCount; i++)
			{

				if (getCellData(i, colNum).equalsIgnoreCase(sTestCaseName))
				{

					break;

				}

			}

			return i;

		}
		catch (Exception e)
		{

			LOG.error("Exception occurred::" +e.getMessage(), e);
			throw (e);

		}

	}

	public int getRowUsed() throws Exception
	{

		try
		{

			int RowCount = sheet.getLastRowNum();

			return RowCount;

		}
		catch (Exception e)
		{
			LOG.error("Exception occurred ::" +e.getMessage(), e);
			throw (e);

		}

	}
	
	/** 
	 * Returns a count of the number of rows of sequential data from the start row.  The number of rows is found when
	 * a blank row is reached
	 * @param startRow the row to start counting from
	 * @return number of sequential rows of data from the start row
	 */
	private int getDataRowCount(int startRow)
	{
    int rowCount = 0;
    XSSFRow row = null;
    outerloop:do 
    {
      row = sheet.getRow(startRow++);
      if (!checkIfRowIsEmpty(row))
      {
    	  if(checkFirstColumn(row))
    	  {
    		  rowCount++;
    	  }
    	  else{
    		  break outerloop;
    	  }
        
      }
    } while (row != null);
    
    return rowCount;
	}
	
	
	private boolean checkIfRowIsEmpty(XSSFRow row) {
		
	    if (row == null) {
	        return true;
	    }
	    if (row.getLastCellNum() <= 0) {
	        return true;
	    }
	    boolean isEmptyRow = true;
	    
	    
	    int cellNum = row.getFirstCellNum();
	    Cell cell = row.getCell(cellNum);
        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK && StringUtils.isNotBlank(cell.toString())) {
            isEmptyRow = false;
        }
       
	    return isEmptyRow;
	}
	
private boolean checkFirstColumn(XSSFRow row) {
	
	    boolean isStartNextTestCase = true;
	    
	    String testcase = "TestCase";
	    int cellNum = row.getFirstCellNum();
	    Cell cell = row.getCell(cellNum);
	   
        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK && StringUtils.isNotBlank(cell.toString()) && (cell.getStringCellValue().contains(testcase))) {
        	isStartNextTestCase = false;
        }
       
	    return isStartNextTestCase;
	}

	public static void main(String args[]){
		int testCaseRow;
		String testCaseName = "createConfiguration";
		XlsHelper xlshelper = new XlsHelper();
		try{
			// Fetching the Test Case row number from the Test Data Sheet
			testCaseRow = xlshelper.getRowContains(testCaseName, 0);

			// Get the Data for the test case
			Object[][] testObjArray = xlshelper.getCellData(testCaseRow);
		}
		catch(Exception e){
			System.out.println(e.toString());
		}
	}
}
