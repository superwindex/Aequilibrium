package com.Helper;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.exception.ToolBoxTestException;

public class SeleniumHelper
{
	private static Log LOG = LogFactory.getLog(SeleniumHelper.class.getName());
	private static SeleniumHelper instance = new SeleniumHelper();
	public static String parentHandle;

	private SeleniumHelper()
	{

	}

	public static SeleniumHelper getInstance()
	{
		return instance;
	}

	public static boolean isElementPresent(String locateBy, String data)
	{
		getDriver().manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		// logger.debug("Is element present"+selector);
		boolean returnVal = true;
		try
		{
			if (locateBy.equalsIgnoreCase("id"))
			{
				getDriver().findElement(By.id(data));
			}
			else if(locateBy.equalsIgnoreCase("xpath"))
			{
				getDriver().findElement(By.xpath(data));
			}
		}
		catch (Exception e)
		{
			LOG.error("Exception :" +e.getMessage(), e);
			returnVal = false;
		}
		finally
		{
			getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		}
		return returnVal;
	}

	public static boolean isAlertPresent()
	{
		try
		{
			getDriver().switchTo().alert();
			return true;
		}
		catch (NoAlertPresentException Ex)
		{
			return false;
		}
	}

	public static boolean switchToFrame(String frame) throws IOException
	{

		LOG.info("switching in iframe");
		try
		{
			String str[] = frame.split("\\|");
			WebDriverWait wait = new WebDriverWait(getDriver(), ConfigHelper.globalWaitTimeout);
			for (int i = 0; i < str.length; i++)
			{
				wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(str[i]));
			}
			return true;
		}
		catch (Exception e)
		{
			LOG.error("Exception occurred while swith to frame::" +e.getMessage(), e);
			return false;
		}
	}

	public static void switchToWindow()
	{
		try
		{
			parentHandle = getDriver().getWindowHandle();			
			Set<String> handle = getDriver().getWindowHandles();
			if (handle.contains(parentHandle))
			{
				handle.remove(parentHandle);
			}
			for (String winHandle : handle)
			{				
				getDriver().switchTo().window(winHandle);
			}
			getDriver().manage().timeouts().implicitlyWait(ConfigHelper.globalImplicitWait, TimeUnit.SECONDS);

		}
		catch (Exception e)
		{
			LOG.error("Exception occurred while swith to window::" +e.getMessage(), e);
			throw new ToolBoxTestException(e);

		}
	}

	public static void writeTextByLocator(String locateBy, String object, String data)
	{

		try
		{
			if (locateBy.equalsIgnoreCase("xpath"))
			{
				getDriver().findElement(By.xpath(object)).click();
				getDriver().findElement(By.xpath(object)).clear();
				getDriver().findElement(By.xpath(object)).click();
				getDriver().findElement(By.xpath(object)).sendKeys(data);
			}
			else if (locateBy.equalsIgnoreCase("id"))
			{
				getDriver().findElement(By.id(object)).click();
				getDriver().findElement(By.id(object)).clear();
				getDriver().findElement(By.id(object)).click();
				getDriver().findElement(By.id(object)).sendKeys(data);
			}
			
		}
		catch (Exception e)
		{
			LOG.error("EXCEPTION_CAUGHT:" + e.toString(), e);
			throw new ToolBoxTestException(e);
		}

	}

	// The method waits till element is clickable
	public static void waitTillElementIsClickable(String locateBy, String data)
	{

		LOG.info("Waiting till element is clickable" + data);
		try
		{
			WebDriverWait wait = new WebDriverWait(getDriver(), ConfigHelper.globalWaitTimeout);
			if (locateBy.equalsIgnoreCase("id"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.id(data)));
			}
			else if (locateBy.equalsIgnoreCase("css"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(data)));
			}
			else if (locateBy.equalsIgnoreCase("xpath"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(data)));
			}
		}
		catch (Exception e)
		{
			LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
			throw new ToolBoxTestException(e);
		}

	}

	// The method waits till element is clickable
	public static void clickByFindElement(String locateBy, String data)
	{

		LOG.info("Waiting till element is clickable" + data);
		try
		{
			if (locateBy.equalsIgnoreCase("id"))
			{
				getDriver().findElement(By.id(data)).click();
			}
			else if (locateBy.equalsIgnoreCase("xpath"))
			{
				getDriver().findElement(By.xpath(data)).click();
			}
			getDriver().manage().timeouts().implicitlyWait(ConfigHelper.globalImplicitWait, TimeUnit.SECONDS);
		}
		catch (Exception e)
		{
			LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
			throw new ToolBoxTestException(e);
		}

	}

	// The method waits till element is clickable and clicks the element
	public static void waitAndClickElement(String locateBy, String data)
	{

		LOG.info("Waiting till element is clickable" + data);
		try
		{
			WebDriverWait wait = new WebDriverWait(getDriver(), ConfigHelper.globalWaitTimeout);
			if (locateBy.equalsIgnoreCase("id"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.id(data)));
				getDriver().findElement(By.id(data)).click();
			}
			else if (locateBy.equalsIgnoreCase("css"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(data)));
				getDriver().findElement(By.cssSelector(data)).click();
			}
			else if (locateBy.equalsIgnoreCase("xpath"))
			{
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(data)));
				getDriver().findElement(By.xpath(data)).click();
			}
		}
		catch (Exception e)
		{
			LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
			throw new ToolBoxTestException(e);
		}

	}

  /**
   * The method waits till the given element is clickable and clicks the element
   * @param element The element to wait for and click
   */
  public static void waitAndClickElement(WebElement element)
  {

    LOG.info("Waiting till element is clickable" + element.getText());
    try
    {
      WebDriverWait wait = new WebDriverWait(getDriver(), ConfigHelper.globalWaitTimeout);
      wait.until(ExpectedConditions.elementToBeClickable(element));
      element.click();
    }
    catch (Exception e)
    {
      LOG.error("EXCEPTION_CAUGHT::" + e.getMessage());
      throw new ToolBoxTestException(e);
    }

  }

	/*
	 * This method fires up an alert, wait for the alert to be presented and then click OK button in alert box.
	 *
	 */
	public static  void waitAndAcceptAlert()
	{
		try
		{
			WebDriverWait wait = new WebDriverWait(getDriver(), ConfigHelper.globalWaitTimeout);
			wait.until(ExpectedConditions.alertIsPresent());

			//Switch focus to the alert popup
			Alert alert = getDriver().switchTo().alert();

			//Click OK button in alert popup
			alert.accept();
		}
		catch (Exception e)
		{
			LOG.error("EXCEPTION_CAUGHT::" + e.getMessage(), e);
			throw new ToolBoxTestException(e);
		}
	}

	private static WebDriver getDriver()
	{
		return DriverHelper.getInstance().getDriver();
	}

	private ConfigHelper getConfigHelper()
	{
		return ConfigHelper.getInstance();
	}

	/*
	 * This method is used to find out whether any cell of the table tableXPath contains the text columnText.
	 *
	 * @param tableColumnsXpath
	 * 		The xpath of table columns
	 * @param columnText
	 * 		The text of column to check against
	 * @return true if any cell of the table tableXPath contains the specified text columnText.
	 */
	public static boolean checkTableContainText (String tableColumnsXpath, String columnText)
	{
		boolean foundRecord = false;

		//Object for all columns in each row of the table which xpath is aTableXPath
		List<WebElement> cells = getDriver().findElements(By.xpath(tableColumnsXpath));
		for (WebElement eachColumn:cells)
		{
			//Check whether cell contains the record
			foundRecord = columnText.matches(eachColumn.getText().toString());
			if (foundRecord) break;
		}
		return foundRecord;
	}
	
	/*
	 * This helper method will check or uncheck the check boxes based on the user preference. 
	 * We might have need to either select all the checkbox or unselect all.
	 * @param option
	 *  String "check" or "uncheck" to be passed.
	 * @param optionXpath
	 *  String with xpath of the checkbox selection.
	 * 	 
	 */
	public static void checkOrUncheckOptions(String option, String optionXpath){
		List<WebElement> els = getDriver().findElements(By.xpath(optionXpath));
	  
		for ( WebElement el : els ) {
			if (option.equalsIgnoreCase("uncheck") && el.isEnabled() )  
	        {  
				el.click();  
	        }  
	        else if (option.equalsIgnoreCase("check") && !el.isEnabled())  
	        { 	         
		        el.click();
	        }
		}
	}
}
