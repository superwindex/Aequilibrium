package com.Helper;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.Reporter;

import com.exception.ToolBoxTestConfigException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Properties;

/**
 * @author Kuppuraj
 * */
public class ConfigHelper {

  private static Log LOG = LogFactory.getLog(ConfigHelper.class.getName());
  // Control how to load properties
  private static final String CONFIG_FILE_NAME = "config.properties";
  
  private static final String GLOBAL_WAIT_TIMEOUT = "global.webDriver.wait.seconds";
  private static final String GLOBAL_TRIPLE_WAIT_TIMEOUT = "global.webDriver.triple.wait.seconds";
  private static final String GLOBAL_IMPLICIT_WAIT = "global.implicit.wait.seconds";
  
  
  private static final String BROWSER = "browser";
 
  private static final String TOOLBOX_BASE_URL = "toolbox.base.url";
  private static final String TOOLBOX_USER = "loginUserID";
    
  // -----------------------------------------------------------------

  public static String toolBoxUrl;
  public static String toolBoxBaseUrl;

  public static  String browser;
  
  public static  String reportPath;
  public static  String archievePath;
  
  public static int globalWaitTimeout;
  public static int globalTriplelWaitTimeout;
 
  public static int globalImplicitWait;
  public static String loggedInUser;
  

  // -----------------------------------------------------------------

  private static  Properties properties;

  private static ConfigHelper instance = new ConfigHelper("ToolboxAutomationConfig");
  
  

  private ConfigHelper(String identity) {
    try {
      loadConfigurationFromPropertyFiles();
      extractProperties();
      printProperties(identity);
    } 
    catch (Exception e)
    {
    	LOG.error("Exception Occurred during configuration:" + e.toString(), e);
    	throw new ToolBoxTestConfigException("Cannot initialize Toolbox Test configuration", e);
    }
  }

  public static ConfigHelper getInstance() {
    return instance;
  }

  private void  loadConfigurationFromPropertyFiles() {
    properties = new Properties();
    loadConfigurationFromPropertyFile();
  }

  private void loadConfigurationFromPropertyFile() {
    try {
      InputStream standardProperty = this.getClass().getClassLoader().getResourceAsStream(CONFIG_FILE_NAME);
    	properties.load(standardProperty);
    } catch (Exception e) {
    	LOG.error("Exception Occurred during load Configuration From PropertyFile:" + e.toString(), e);
    	throw new ToolBoxTestConfigException("Cannot find/load standard property file from classpath: '" + CONFIG_FILE_NAME + "'", e);
    }
  }

  
  private static void extractProperties() {
	  
    globalWaitTimeout = Integer.valueOf(((String) properties.get(GLOBAL_WAIT_TIMEOUT))).intValue();
    globalTriplelWaitTimeout = Integer.valueOf(((String) properties.get(GLOBAL_TRIPLE_WAIT_TIMEOUT))).intValue();
    globalImplicitWait = Integer.valueOf(((String) properties.get(GLOBAL_IMPLICIT_WAIT))).intValue();
    
 
    toolBoxBaseUrl = (String) properties.get(TOOLBOX_BASE_URL);
    toolBoxUrl = toolBoxBaseUrl;    
    loggedInUser = properties.getProperty(TOOLBOX_USER);
    
    browser = (String) properties.get(BROWSER);
    
    reportPath = System.getProperty("user.dir") + "\\test-output";   
    archievePath = System.getProperty("user.dir") + "\\Archieve_Output\\";

  }

  
  public static String getToolboxUrl() {
	  return toolBoxUrl;
  }
  
  public static String getEnvironmentName() {
	  
	  String env = null;
	  return env;
  }
  
  
  public static String getValueFromKey(String key) {
    return properties.getProperty(key);
  }
  
  private void printProperties(String identity) {
    String desc = "Config for '" + identity + "': " + this;
    Reporter.log(desc);
  }

  @Override
  public  String toString() {
    return "Config [" + ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE) + "]";
  }
  
	// Clear the temp folder
	// Gets the temp folder property from the System property itself
  	//Need to work more on this
	public static  void clearTempFolder() throws IOException
	{

		try
		{
			File file = new File(System.getProperty("java.io.tmpdir"));
			//FileUtils.cleanDirectory(file);
		}

		catch (Exception e)
		{
			// Do nothing since we do not worry about the files that cannot be
			// deleted
			// Include exception handler logic if you want to
		}
	} 
	
	//Copy the test-output report folder to Archive folder
	public static void copyToArchiveFolder()
	{
		String destFileName = "test-output";
		File source = new File(reportPath);
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH-mm-ss");
	    String ts=sdf.format(source.lastModified());
	    File destination=new File(archievePath+destFileName+"_"+ts);
	    try
		{
			FileUtils.copyDirectory(source,destination);
		}
	   
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			LOG.error("Exception occured on moving the report folder "
					+ "to archieve folder:::" +e.toString(), e);
		}

	}  
}