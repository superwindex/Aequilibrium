package com.Helper;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.exception.ToolBoxTestConfigException;
import com.exception.ToolBoxTestException;

public class DriverHelper
{
	private static Log LOG = LogFactory.getLog(DriverHelper.class.getName());
	private static DriverHelper instance = new DriverHelper();
	
	private ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();

	private DesiredCapabilities browserCapabilities = null;
	
	
	private DriverHelper() {
	  }

	  public static DriverHelper getInstance() {
	    return instance;
	  }

	public void startDriver(String browser) throws Exception {
	    try 
	    {    	
	       DesiredCapabilities cap = new DesiredCapabilities();
	       cap.setBrowserName(browser);
	      
	        if (browser.equals("firefox")) 
	        {     
	          FirefoxProfile customProfile = new FirefoxProfile();
	          customProfile.setPreference("dom.disable_beforeunload", true);
	         
	          driver.set(new FirefoxDriver(this.browserCapabilities));
	         
	          driver.get().manage().window().maximize();
	        }
	        else if (browser.equals("chrome")) 
	        {
	          this.browserCapabilities = DesiredCapabilities.chrome();
	          File chromeDriver = new File(System.getProperty("user.dir"), "/src/main/java/com/driver/chromedriver.exe");
	          System.setProperty("webdriver.chrome.driver", chromeDriver.getAbsolutePath());
	          driver.set(new ChromeDriver(this.browserCapabilities));
	          driver.get().manage().window().maximize();
	        }
	        else if (browser.equals("ie32")) 
	        {
	          cap.setBrowserName("iexplorer");
	          cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
	          cap.setCapability("nativeEvents",false);
	          cap.setCapability("enablePersistentHover ", false);
	          this.browserCapabilities = DesiredCapabilities.internetExplorer();
	          this.browserCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	          System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/src/main/java/com/driver/IEDriverServer32.exe");
	          driver.set(new InternetExplorerDriver(this.browserCapabilities));
	          driver.get().manage().window().maximize();
	        }
	        else if (browser.equals("ie64")) 
	        {
	          cap.setBrowserName("iexplorer");
	          cap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
	          cap.setCapability("nativeEvents",false);
	          cap.setCapability("enablePersistentHover ", false);
	          this.browserCapabilities = DesiredCapabilities.internetExplorer();
	          this.browserCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	          System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/src/main/java/com/driver/IEDriverServer64.exe");
	          driver.set(new InternetExplorerDriver(this.browserCapabilities));
	          driver.get().manage().window().maximize();
	        }
	        else
	        {
	          throw new ToolBoxTestConfigException("Specify the valid browser in config.properties file");
	        }
	        long implicitWaitTime = Long.parseLong("30");
	        driver.get().manage().timeouts().implicitlyWait(implicitWaitTime, TimeUnit.SECONDS);
	    } catch (Exception e) {
	    	LOG.error("Exception in starting driver::" +e.getMessage(), e);
	    	throw new ToolBoxTestException("Exception in starting driver::" +e);
	    }
	  }
	
	public WebDriver getDriver() {
	    return driver.get();
	  }
	
	public void cleanDriverSession() {
	    try 
	    {
	      getDriver().manage().deleteAllCookies();
	    } 
	    catch (Exception e)
	    {
	    	LOG.error("Exception in driver manager cookies delete::" +e.getMessage(), e);
	    }
	  }
	
	public static String getStatusString(int status) {
	    switch(status) {
	      case 1:
	        return "SUCCESS";
	      case 2:
	        return "FAILURE";
	      case 3:
	        return "SKIP";
	      case 4:
	        return "SUCCESS_PERCENTAGE_FAILURE";
	      case 16:
	        return "STARTED";
	    }
	    return "Unknow";
	  }

	
}
