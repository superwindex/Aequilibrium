package com.Helper;


import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.annotations.DataProvider;

import com.exception.ToolBoxTestConfigException;
import com.Helper.XlsHelper;

/**
 * This class is used to retrieve the data from Excel spreadsheet 
 * and feed into test method through DataProvider annotation
 * 
 * @author Wen Huang
 * @version 
 * 
 */
public class DataProviderHelper 
{
	 private static Log LOG = LogFactory.getLog(DataProviderHelper.class.getName());
	 /**
	  * This method takes the test method name and retrieves the data from Excel spreadsheet 
	  * to feed into the each test method.
	  *    
	  * @param method - test method
	  * @return Object array with all data passed from Test_Data.xlsx. 
	  * This array will be used to feed into test method as parameters.
	  */

	
	 	  
	/* @DataProvider(name="getTestData") 
	 public static Object[][] dataProvider(Method method) throws Exception
	{
			try
			{
				LOG.info("Inside data provider getLessonInfo()");

				int testCaseRow;
				String testCaseName = method.getName();

				// Fetching the Test Case row number from the Test Data Sheet
				testCaseRow = XlsHelper.getInstance().getRowContains(testCaseName, 0);

				// Get the Data for the test case
				Object[][] testObjArray = XlsHelper.getInstance().getCellData(testCaseRow);
				
				return (testObjArray);
			}
			catch (Exception e)
			{
				LOG.error("Exception in reading testData from excel::" + e.getMessage(), e);
				throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);
			}
	}
	*/
	
	 /**
	  * This method takes the constructor name and retrieves the data from Excel spreadsheet 
	  * to feed into the constructor in the class.
	  *    
	  * @param constructor - Constructor of a class
	  * @return Object array with all data passed from Test_Data.xlsx
	  */
	/* @DataProvider
	 public static Object[][] provideClassData(Constructor constructor)
	{
		 String [] constructorSeparatedNameList = constructor.getName().split("\\.");
		 String constructorName = constructorSeparatedNameList[constructorSeparatedNameList.length-1];
			try
			{
				LOG.info("Inside data provider provideClassData()");
	
				int testCaseRow;
	
				// Fetching the Test Case row number from the Test Data Sheet
				testCaseRow = XlsHelper.getInstance().getRowContains(constructorName, 0);
	
				// Get the Data for the test case
				Object[][] testObjArray = XlsHelper.getInstance().getCellData(testCaseRow);
	
				return (testObjArray);
			}
			catch (Exception e)
			{
				LOG.error("Exception in reading testData from excel::" + e.getMessage(), e);
				throw new ToolBoxTestConfigException("Exception in reading testData from excel::" + e);
			}
	}
	*/
}
